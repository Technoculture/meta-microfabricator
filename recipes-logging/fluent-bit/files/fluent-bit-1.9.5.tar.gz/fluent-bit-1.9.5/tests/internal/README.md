# Fluent Bit Internal Tests

The following directory contains unit tests to validate specific functions of Fluent Bit core (not plugins).
