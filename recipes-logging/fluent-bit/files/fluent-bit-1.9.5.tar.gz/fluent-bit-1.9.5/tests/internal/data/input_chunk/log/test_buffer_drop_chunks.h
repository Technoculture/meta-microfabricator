#define TEST_BUFFER_DROP_CHUNKS	"["		\
	"1598279645,"			\
	"{"				\
	"\"key_0\": false,"		\
	"\"key_1\": false,"		\
	"\"key_2\": false,"		\
	"\"key_3\": false,"		\
	"\"key_4\": false,"		\
	"\"key_5\": false,"		\
	"\"key_6\": false,"		\
	"\"key_7\": false,"		\
	"\"key_8\": false,"		\
	"\"key_9\": false,"		\
	"\"key_10\": false,"		\
	"\"key_11\": false,"		\
	"\"key_12\": false,"		\
	"\"key_13\": false,"		\
	"\"key_14\": false,"		\
	"\"key_15\": false,"		\
	"\"key_16\": false,"		\
	"\"key_17\": false,"		\
	"\"key_18\": false,"		\
	"\"key_19\": false,"		\
	"\"key_20\": false,"		\
	"\"END_KEY\": \"JSON_END\""		\
	"}]"

