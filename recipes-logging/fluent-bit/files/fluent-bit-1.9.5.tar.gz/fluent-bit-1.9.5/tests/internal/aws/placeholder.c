#include "../flb_tests_internal.h"

static void test_placeholder()
{
    return;
}

TEST_LIST = {
    { "placeholder" , test_placeholder },
    { 0 }
};
