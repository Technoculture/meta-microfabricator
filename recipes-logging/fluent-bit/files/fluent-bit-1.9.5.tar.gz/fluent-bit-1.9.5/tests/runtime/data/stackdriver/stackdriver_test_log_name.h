#define LOG_NAME_OVERRIDE	"[" \
	"1591111124," \
	"{"	\
        "\"custom_log_name_key\": \"custom_log_name\"" \
	"}]"

#define LOG_NAME_NO_OVERRIDE	"[" \
	"1591111124," \
	"{"	\
	"}]"
