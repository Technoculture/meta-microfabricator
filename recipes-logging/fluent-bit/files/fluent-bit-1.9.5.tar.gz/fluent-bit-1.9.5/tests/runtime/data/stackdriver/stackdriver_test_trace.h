#define TRACE_COMMON_CASE	"[" \
	"1591111124," \
	"{"	\
        "\"trace\": \"test-trace-id-xyz\"" \
	"}]"
	