/* -*- Mode: C; tab-width: 4; indent-tabs-mode: nil; c-basic-offset: 4 -*- */

#define JSON_ES	"["                             \
    "1448403340,"                               \
    "{"                                         \
    "\"key_0\": false,"                         \
    "\"key_1\": true,"                          \
    "\"key_2\": \"some string\","               \
    "\"key_3\": 0.12345678,"                    \
    "\"key.4\": 5000,"                          \
    "\"END_KEY\": \"JSON_END\""                 \
    "}]"


#define JSON_DOTS                                                       \
    "[1448403340,"                                                      \
    "{\".le.vel\":\"error\", \".fo.o\":[{\".o.k\": [{\".b.ar\": \"baz\"}]}]}]"
