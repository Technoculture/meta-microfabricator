=== Miniz Version ===

commit b43f8a0c22d6bae6b5416264232f57a2aca539fe 
Merge: 17d6763 1e8c7ce
Author: Martin Raiber <martin@urbackup.org>
Date:   Sun Feb 7 22:03:46 2021 +0100

    Merge pull request #147 from andiwand/write-with-dynamic-size
    write with dynamic size
